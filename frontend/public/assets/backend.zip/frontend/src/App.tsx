import { useInternetIdentity } from './hooks/useInternetIdentity';
import { useActor } from './hooks/useActor';
import { useGetCallerUserProfile } from './hooks/useQueries';
import LoginPage from './pages/LoginPage';
import ProfileSetupPage from './pages/ProfileSetupPage';
import MainLayout from './components/MainLayout';
import { Toaster } from '@/components/ui/sonner';
import { useEffect, useState } from 'react';
import { isAuthorizedAdmin } from './lib/authAdmin';

function App() {
  const { identity, isInitializing } = useInternetIdentity();
  const { actor, isFetching: actorFetching } = useActor();
  const { data: userProfile, isLoading: profileLoading, isFetched, error: profileError, refetch } = useGetCallerUserProfile();

  const [bypassProfileSetup, setBypassProfileSetup] = useState(false);
  const [retryAttempt, setRetryAttempt] = useState(0);
  const [inactiveAccountError, setInactiveAccountError] = useState(false);
  const [showApp, setShowApp] = useState(false);

  const isAuthenticated = !!identity;
  const isMasterAdmin = isAuthorizedAdmin(userProfile?.email);

  // CRITICAL: Check if user account is active
  useEffect(() => {
    if (isAuthenticated && isFetched && userProfile) {
      const isAdminUser = isMasterAdmin || userProfile.role === 'admin';
      
      if (!isAdminUser && !userProfile.active) {
        console.log('User account is not active');
        setInactiveAccountError(true);
      } else {
        setInactiveAccountError(false);
      }
    }
  }, [isAuthenticated, isFetched, userProfile, isMasterAdmin]);

  // CRITICAL: Master Admin bypass - skip profile loading issues entirely
  useEffect(() => {
    if (isAuthenticated && isFetched && userProfile && isMasterAdmin) {
      console.log('Master admin detected - bypassing all profile checks');
      setBypassProfileSetup(true);
      setShowApp(true);
    }
  }, [isAuthenticated, isFetched, userProfile, isMasterAdmin]);

  // CRITICAL: Master Admin bypass for profile fetch failures
  useEffect(() => {
    if (isAuthenticated && (profileError || (isFetched && !userProfile)) && actor) {
      actor.getDefaultAdminProfile().then((defaultAdmin) => {
        if (defaultAdmin && isAuthorizedAdmin(defaultAdmin.email)) {
          console.log('Master admin detected via default profile - bypassing error screen');
          setBypassProfileSetup(true);
          setShowApp(true);
        }
      }).catch((err) => {
        console.error('Error checking default admin:', err);
      });
    }
  }, [isAuthenticated, profileError, isFetched, userProfile, actor]);

  // CRITICAL: Automatic retry mechanism with timeout
  useEffect(() => {
    if (isAuthenticated && profileLoading && retryAttempt === 0 && !isMasterAdmin) {
      const timeoutId = setTimeout(() => {
        console.log('Profile loading timeout - attempting retry');
        setRetryAttempt(1);
        refetch();
      }, 5000);

      return () => clearTimeout(timeoutId);
    }
  }, [isAuthenticated, profileLoading, retryAttempt, isMasterAdmin, refetch]);

  // CRITICAL: Second retry with automatic bypass
  useEffect(() => {
    if (isAuthenticated && retryAttempt === 1 && (profileError || isFetched) && !isMasterAdmin) {
      const timeoutId = setTimeout(() => {
        console.log('Second profile loading attempt timeout - bypassing profile setup');
        setBypassProfileSetup(true);
        setShowApp(true);
      }, 5000);

      return () => clearTimeout(timeoutId);
    }
  }, [isAuthenticated, retryAttempt, profileError, isFetched, isMasterAdmin]);

  // CRITICAL: Automatic bypass after failed retries
  useEffect(() => {
    if (isAuthenticated && retryAttempt >= 1 && (profileError || (isFetched && !userProfile)) && !isMasterAdmin) {
      console.log('Profile loading failed after retry - automatically bypassing');
      const timeoutId = setTimeout(() => {
        setBypassProfileSetup(true);
        setShowApp(true);
      }, 2000);

      return () => clearTimeout(timeoutId);
    }
  }, [isAuthenticated, retryAttempt, profileError, isFetched, userProfile, isMasterAdmin]);

  // CRITICAL: Show app when profile is loaded successfully
  useEffect(() => {
    if (isAuthenticated && isFetched && userProfile && !inactiveAccountError) {
      setShowApp(true);
    }
  }, [isAuthenticated, isFetched, userProfile, inactiveAccountError]);

  // Optimized loading state for initial authentication
  if (isInitializing) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0078D7] mx-auto mb-4"></div>
          <p className="text-gray-600 font-normal" style={{ fontFamily: 'Century Gothic, Gothic A1, sans-serif' }}>
            Initializing...
          </p>
        </div>
      </div>
    );
  }

  // Not authenticated - show login
  if (!isAuthenticated) {
    return <LoginPage />;
  }

  // CRITICAL: Show inactive account error
  if (inactiveAccountError) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
          <div className="mb-4">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100">
              <svg className="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </div>
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Century Gothic, Gothic A1, sans-serif' }}>
            Account Not Active
          </h2>
          <p className="text-gray-600 mb-6" style={{ fontFamily: 'Century Gothic, Gothic A1, sans-serif', fontWeight: 400 }}>
            Your account is not active. Please contact the administrator.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="w-full px-4 py-2 bg-[#0078D7] text-white rounded-md hover:bg-[#005a9e] transition-colors font-normal"
            style={{ fontFamily: 'Century Gothic, Gothic A1, sans-serif' }}
          >
            Back to Login
          </button>
        </div>
      </div>
    );
  }

  // CRITICAL: Master Admin should NEVER see any blocking screens
  const showProfileSetup = isAuthenticated && !profileLoading && isFetched && userProfile === null && !bypassProfileSetup && !isMasterAdmin;

  if (showProfileSetup) {
    return <ProfileSetupPage onBypass={() => { setBypassProfileSetup(true); setShowApp(true); }} />;
  }

  // Optimized loading state - show app faster
  if ((profileLoading || !isFetched || actorFetching) && !bypassProfileSetup && !isMasterAdmin && !showApp && retryAttempt < 2) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0078D7] mx-auto mb-4"></div>
          <p className="text-gray-600 font-normal" style={{ fontFamily: 'Century Gothic, Gothic A1, sans-serif' }}>
            {actorFetching ? 'Connecting...' : retryAttempt === 0 ? 'Loading...' : 'Retrying...'}
          </p>
        </div>
      </div>
    );
  }

  // All checks passed or bypassed - show main app
  return (
    <>
      <MainLayout />
      <Toaster />
    </>
  );
}

export default App;

