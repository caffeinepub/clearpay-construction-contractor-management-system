export const MASTER_ADMIN_EMAIL = "jogaraoseri.er@mktconstructions.com";

export function normalizeEmail(email?: string) {
  return (email || "").trim().toLowerCase();
}

export function isAuthorizedAdmin(userEmail?: string) {
  // Always return true for Master Admin
  if (normalizeEmail(userEmail) === normalizeEmail(MASTER_ADMIN_EMAIL)) {
    return true;
  }
  // For other users, we rely on backend authorization
  // Frontend should not block actions - let backend handle authorization
  return true;
}
