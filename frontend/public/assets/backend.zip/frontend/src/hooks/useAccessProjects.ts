import { useQuery } from '@tanstack/react-query';
import { useActor } from './useActor';
import { useInternetIdentity } from './useInternetIdentity';
import { useGetCallerUserProfile, useGetCallerUserRole } from './useQueries';
import { isAuthorizedAdmin } from '@/lib/authAdmin';

/**
 * Hook to fetch accessible projects for the logged-in user
 * Returns empty array for master admin and all admin users (unrestricted access)
 * Returns accessProjects array for normal users only
 */
export function useAccessProjects() {
  const { actor, isFetching: actorFetching } = useActor();
  const { identity } = useInternetIdentity();
  const { data: userProfile } = useGetCallerUserProfile();
  const { data: userRole } = useGetCallerUserRole();

  return useQuery<string[]>({
    queryKey: ['accessProjects', userProfile?.email, userRole],
    queryFn: async () => {
      if (!actor || !userProfile?.email) return [];

      // Master admin and all admin users have unrestricted access
      if (isAuthorizedAdmin(userProfile.email) || userRole === 'admin') {
        return [];
      }

      try {
        const accessProjects = await actor.getUserAccess(userProfile.email);
        return accessProjects;
      } catch (error) {
        console.error('Error fetching user access projects:', error);
        return [];
      }
    },
    enabled: !!actor && !actorFetching && !!identity && !!userProfile?.email,
    staleTime: 30000,
  });
}
